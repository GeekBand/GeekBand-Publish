//
//  Book.swift
//  TableViewDemo
//
//  Created by yarshure on 15/7/15.
//  Copyright © 2015年 yarshure. All rights reserved.
//



class Book {

    var title: String?
    var author:Author?
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
