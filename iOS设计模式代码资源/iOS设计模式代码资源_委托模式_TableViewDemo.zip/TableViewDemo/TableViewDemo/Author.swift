//
//  Author.swift
//  TableViewDemo
//
//  Created by yarshure on 15/7/15.
//  Copyright © 2015年 yarshure. All rights reserved.
//

import Foundation

class Author {
    var name:String?
    var desc:String?
    
}