//
//  TableViewDemo-Swift.h
//  TableViewDemo
//
//  Created by yarshure on 15/7/15.
//  Copyright © 2015年 yarshure. All rights reserved.
//

#ifndef TableViewDemo_Swift_h
#define TableViewDemo_Swift_h

@class Book;

#endif /* TableViewDemo_Swift_h */
