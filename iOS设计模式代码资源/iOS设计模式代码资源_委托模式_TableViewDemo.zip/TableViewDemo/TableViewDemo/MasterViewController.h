//
//  MasterViewController.h
//  TableViewDemo
//
//  Created by yarshure on 15/7/8.
//  Copyright (c) 2015年 yarshure. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController


@end

